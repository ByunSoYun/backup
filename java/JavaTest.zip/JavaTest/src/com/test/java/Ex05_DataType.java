package com.test.java;

public class Ex05_DataType {
	public static void main(String[] args) {
		
		//1. 9개 자료형
		//2. 주변의 데이터 선택
		//3. 자료형 선택 + 변수 생성 + 데이터 대입 + 화면 출력 
		//4. 각 자료형 x10
		
	
		
		byte EnglishScore;
		EnglishScore = 90;
		System.out.println("내 영어점수는 " + EnglishScore +"점 입니다." );
	
		
		short Height;
		Height = 160;
		System.out.println("제 키는 " + Height + "cm 입니다.");
		
		int Money;
	    Money = 100000;
		System.out.println("내가 가진 돈은 " + Money + "원 입니다.");
		
		long Korean;
		Korean = 51821669; 
		System.out.println("한국 인구수는 " + Korean + "명 입니다.");
		
		float Vision;
		Vision = 1.2F;
		System.out.println("내 시력은 " + Vision + "입니다.");
		
		double Weight;
		Weight =47.7418;
		System.out.println("내 몸무게는 " + Weight +"Kg 입니다.");
		
		char Score;
		Score = 'A';
		System.out.println("내 학점은 " + Score + "입니다.");
		
		boolean A;
		A = true;
		System.out.println("나는 여자다 : "+ A);
		
		
	    
		String Time;
		Time = "점심시간";
		System.out.println("지금 시간은 " + Time + "입니다." +"\n"+"\n"+"\n");
		
		//1번째---------------------------------------------
		
		
		byte MathScore;
		MathScore = 75;
		System.out.println("내 수학점수는 " + MathScore +"점 입니다." );
	
		
		Short Foot;
		Foot = 225;
		System.out.println("내 발길이는 " + Foot + "cm 입니다.");
		
		int Age;
		Age = 25;
		System.out.println("내 나이는 " + Age + "살 입니다.");
		
		long Bookpage;
		Bookpage = 498;
		System.out.println("지금 읽은 책 페이지는" + Bookpage + "p 입니다.");
		
		float Length;
		Length = 30.234F;
		System.out.println("내 손의 길이는 " + Length +"cm 입니다.");
		
		double Shoes;
		Shoes = 0.847292;
		System.out.println("이 신발의 무게는 " + Shoes + "Kg 입니다.");
		
		char Fail;
		Fail = 'F';
		System.out.println("우리는 Fail을 " + Fail + "로 표현한다.");
		
		boolean B;
		B = false;
		System.out.println("나는 남자다 : "+ B);
		
		
		String Address;
		Address = "인천";
		System.out.println("제가 사는 곳은 " + Address + "입니다."+"\n"+"\n"+"\n");
		
		
	//2번째-----------------------------------------------------------
		
		
		
		
		
		
		byte Student;
		 
		Student = 31;
				
		System.out.println("우리반 학생수는 " + Student + "명 입니다.");
		
		short Hair;
		Hair = 60;
		System.out.println("제 머리길이는 " + Hair + "cm 입니다.");
		
		int Distance;
		Distance = 489385;
		System.out.println("여기서 학교까지 거리는" + Distance + "m 입니다.");
		
		long Mail;
		Mail = 51821669; 
		System.out.println("전송된 메일의 수가 " + Mail + "개 입니다.");
		
		float Frequency;
		Frequency = 100.3F;
		System.out.println("지금 주파수 " + Frequency + "Hz입니다.");
		
		double Pencil;
		Pencil =0.534;
		System.out.println("이 연필은 " + Pencil +"mm 입니다.");
		
		
		char Plus;
		Plus = '+';
		System.out.println("우리는 덧셈기호를 " + Plus + "로 쓴다.");
		
		boolean C;
		C = true;
		System.out.println("올해는 2021년이다 : "+ C);

	    
		String Class;
		Class = "프로그래밍 수업";
		System.out.println("내가 지금 수업 듣는건" + Class + "입니다."+"\n"+"\n"+"\n");
	//3번쨰------------------------------------------------------------
		
		byte Study;
		 
		Study = 8;
				
		System.out.println("나는 공부를 " + Study + "시간 한다.");
		
		short Tissue;
		Tissue = 100;
		System.out.println("이 티슈는 " + Tissue + "장 들어있습니다.");
		
		int Price;
		Price = 15000;
		System.out.println("이것의 가격은" + Price+ "원 입니다.");
		
		long Cloth;
		Cloth = 98; 
		System.out.println("옷의 개수는 " + Cloth + "개 입니다.");
		
		float Kcal;
		Kcal = 602.4F;
		System.out.println("이 음식의 칼로리는 " + Kcal + " 칼로리입니다.");
		
		double Chair;
		Chair =1.3982;
		System.out.println("이 의자는 " + Chair +"Kg 입니다.");
		
		char Size;
		Size = 'M';
		System.out.println("이 옷의 사이즈는 " + Size + "입니다.");
		
		boolean D;
		D = true;
		System.out.println("오늘은 비가 안온다 : " + D);
	    
		String Team;
		 Team= "3조";
		System.out.println("제 조는" + Team + "입니다."+"\n"+"\n"+"\n");
	//4번쨰--------------------------------------------------------
		
		byte Shower;
		 
		Shower = 1;
				
		System.out.println("나는 샤워를 하루에 " + Shower + "번 한다.");
		
		short Game;
		Game = 120;
		System.out.println("나는 하루에 게임을 " + Game + "분 한다.");
		
		int Incheon;
		Incheon = 2941705;
		System.out.println("인천 인구수는" + Incheon+ "명 입니다.");
		
		long Bag;
		Bag = 13; 
		System.out.println("가방의 개수는 " + Bag + "개 입니다.");
		
		float FriendWeight;
		FriendWeight = 45.345F;
		System.out.println("내 친구의 몸무게는 " + FriendWeight + " Kg 입니다.");
		
		double Friendheight;
		Friendheight =159.23;
		System.out.println("내 친구의 키는 " + Friendheight +"cm 입니다.");
		
		char BloodType;
		BloodType = 'B';
		System.out.println("제 혈액형은 " + BloodType  + "형 입니다.");
		
		boolean E;
		E = false;
		System.out.println("나는 키가 170cm가 넘는다.: " + E);
	    
		String Name;
		 Name = "변소윤";
		System.out.println("제 이름은 " + Name + "입니다."+"\n"+"\n"+"\n");
		
		
		//5번쨰--------------------------------------------------------
		

		byte Meal;
		 
		Meal = 2;
				
		System.out.println("나는 식사를 하루에 " + Meal + "번 한다.");
		
		short Chocolate;
		Chocolate = 5;
		System.out.println("나는 수업중에 초콜릿 " + Chocolate + "개 먹었다.");
		
		int Ring;
		Ring = 350000;
		System.out.println("이 반지는" + Ring+ "원 입니다.");
		
		long Chinese;
		Chinese = 1444210000; 
		System.out.println("중국 인구수는 " + Chinese + "명 입니다.");
		
		float Milk;
		Milk = 300.28F;
		System.out.println("남은우유의 양은 " + Milk + " ml 입니다.");
		
		double Beer;
		Beer =159.23;
		System.out.println("남은 맥주의 양은 " + Beer +"CC 입니다.");
		
		char Right;
		Right = 'O';
		System.out.println("우리는 맞다는 표시를 " + Right  + "로 한다.");
		
		boolean F;
		F = true;
		System.out.println("나는 아이폰을 사용중이다: " + F);
	    
		String PhoneNumber;
		PhoneNumber = "010-8703-1259";
		System.out.println("제 전화번호는 " + PhoneNumber + "입니다."+"\n"+"\n"+"\n");
		
		//6번째--------------------------------------------------------------------
		
		byte Cookie;
		 
		Cookie = 2;
				
		System.out.println("나는 하루에 과자를 " + Cookie + "개 먹는다.");
		
		short Coffee;
		Coffee = 1;
		System.out.println("나는 하루에 커피를 " + Coffee + "L 먹는다.");
		
		int Fan;
		Fan = 500000;
		System.out.println("저 연예인의 팬클럽 회원수는" + Fan+ "명 입니다.");
		
		long BitCoin;
		BitCoin = 123425223; 
		System.out.println("이 비트코인의 가치는 " + BitCoin + "원 입니다.");
		
		float Pi;
		Pi = 3.14F;
		System.out.println("원주율의 값은 " + Pi + " 입니다.");
		
		double Percentage;
		Percentage =0.000012425;
		System.out.println("복권에 당첨될 가능성은 " + Percentage +"% 입니다.");
		
		char Wrong;
		Wrong = 'X';
		System.out.println("우리는 틀리다는 표시를 " + Wrong  + "로 한다.");
		
		boolean G;
		G= false;
		System.out.println("나는 중국인이다: " + E);
	    
		String Adult;
		Adult = "성인";
		System.out.println("저는 " + Adult + "입니다."+"\n"+"\n"+"\n");
		
		
		//7번째--------------------------------------------------------------------
		
				byte Delivery;
				 
				Delivery = 2;
						
				System.out.println("나는 일주일에 배달음식을 " + Delivery + "번 시킨다.");
				
				short Arm;
				Arm = 50;
				System.out.println("내 팔길이는 " + Coffee + "cm 입니다.");
				
				int Tv;
				Tv = 200;
				System.out.println("나는 하루에 Tv를 " + Tv + "분 시청합니다.");
				
				long Iphone;
				Iphone = 1400000; 
				System.out.println("내 아이폰의 가격은 " + Iphone + "원 입니다.");
				
				float Spray;
				Spray = 30.48F;
				System.out.println("이 스프레이는 " + Spray + "ml 남았습니다.");
				
				double Content ;
				Content  = 70;
				System.out.println("소세지의 고기함량은 " + Percentage +"% 입니다.");
				
				char Minus;
				Minus = '-';
				System.out.println("우리는 뺴기 기호로 " + Minus  + "를 쓴다.");
				
				boolean H;
				H= true;
				System.out.println("나는 한국인이다: " + H);
			    
				String Female;
				Female = "여자";
				System.out.println("저는 " + Female + "입니다."+"\n"+"\n"+"\n");
				
				//8번째--------------------------------------------------------------------
				
				byte Jeju;
				 
				 Jeju = 3;
						
				System.out.println("나는 제주도를" + Jeju + "번 가봤다.");
				
				short DryIce;
				DryIce = -78;
				System.out.println("드라이아이스의 온도는 " + DryIce + "도 입니다.");
				
				int Year;
				Year = 365;
				System.out.println("일년은 " + Year + "일이다.");
				
				long TvPrice;
				TvPrice = 1500000; 
				System.out.println("Tv의 가격은 " + TvPrice + "원 입니다.");
				
				float Degree;
				Degree = 36.5F;
				System.out.println("내 체온은 " + Degree + "도 이다.");
				
				double Average ;
				Average  = 72.342156;
				System.out.println("시험 평균 점수는 " + Average +"점 입니다.");
				
				char Equal;
				Equal = '=';
				System.out.println("우리는 등호를 기호로 " + Equal  + "를 쓴다.");
				
				boolean J;
				J= false;
				System.out.println("하루는 25시간이다: " + J);
			    
				String Seoul;
				Seoul = "서울";
				System.out.println("우리 학원은 " + Seoul + "에 있습니다."+"\n"+"\n"+"\n");
				
				
	//9번째--------------------------------------------------------------------
				
				byte Finger;
				 
				Finger = 10;
						
				System.out.println("내손가락은" + Finger + "개다");
				
				short Room;
				Room = 18;
				System.out.println("방의 온도는 " + Room + "도 입니다.");
				
				int Day;
				Day = 24;
				System.out.println("하루은 " + Day + "시간이다.");
				
				long Computer;
				Computer = 1000000; 
				System.out.println("컴퓨터의 가격은 " + Computer + "원 입니다.");
				
				float Water;
				Water = 40.23F;
				System.out.println("이 물의 온도는 " + Water + "도 이다.");
				
				double MathScoreAverage ;
				MathScoreAverage  = 72.342156;
				System.out.println("수학 시험 평균 점수는 " + MathScoreAverage +"점 입니다.");
				
				char Dollar;
				Dollar = '$';
				System.out.println("우리는 달러를 기호로 " + Dollar  + "를 쓴다.");
				
				boolean K;
				K= true;
				System.out.println("나는 발이 225이다: " + K);
			    
				String Academe;
				Academe = "쌍용교육센터";
				System.out.println("우리 학원의 이름은 " + Academe + "입니다."+"\n"+"\n"+"\n");
				
				
				
			System.out.printf(formatdata,);
			
				//10번째--------------------------------------------------------------------
	}

}
