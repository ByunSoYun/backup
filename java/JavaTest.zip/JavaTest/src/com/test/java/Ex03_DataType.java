package com.test.java;

public class Ex03_DataType {
	public static void main(String[] args) {
		/*
		 
		 
		 
		 자료형,Data Type p55-p85
		 -데이터의 형태,길이(범위)등을 미리 정의하고 분류한 규칙(약속)
		 
		 "숫자"
		 100
		 200
		 300
		 
		 "문자"
		
		 홍길동
		 아무개 
		 하하하
		
		 자바 언어의 자료형 
		 
		 
		 
		 
		 
		 */
		
		byte kor;
		
		kor = 100;
		
		System.out.println(10);
		System.out.println(kor);
		//너비, 높이, 거리 
		//byte width = 100,height = 50, distance = 70
		
		//byte width =100; //넓이 
		//byte height = 50; // 높이
		//byte distance =70; //거리
		
		byte width = 100,
				
				height = 50, 
				
				distance = 70;
		
		byte a = 10;
		byte b;
		//b = 20;
		b=a;//a변수안의 데이터를 가져와서 b변수에 복사해라
		    //  즉 이 a는 장소의 의미가아니라 데이터를 의미
		
		System.out.println(b);
		
		
	}

}
