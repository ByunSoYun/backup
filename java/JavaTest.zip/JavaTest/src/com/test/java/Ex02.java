package com.test.java;

public class Ex02 {
public static void main(String[] args) {
	
	System.out.println("================");
	System.out.println("  음료가격(단위:원)");
	System.out.println("================");
	System.out.printf("1. 콜라: %d\n",2500);
	System.out.printf("2. 스무디: %d\n",3500);
	System.out.printf("3. 쿠키: %d\n",500);
	System.out.printf("4. 아메리카노: 쿠키: %d\n",12500);
	System.out.println();
	System.out.println();
		
	
	
}
}
