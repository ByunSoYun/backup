package com.test.java;

public class Ex01 {
	public static void main(String[] args) {
		
		int num;
		
		num = 0;// 사용자가 키보드로 입력한 숫자 > 경우의 숫자? > 42억 
	
		
		// 나눗셈
		//피제수 / 제수
		// - 정수의 나눗셈은 제수가 0이 될 수 없다
		//java.lang.ArithmeticException / by zero
	 System.out.printf("100/%d=%d\n",num,100/num);


	}

}
