package com.test.java;

public class Task {
	public static void main(String[] args) {
		
		String Name = "홍길동";
		byte Age = 20;
		String Gender = "남자";
		String Address = "서울시 강남구 역삼동";
		
		System.out.printf("안녕하세요. 제 이름은 '%s'입니다.\n", Name);
		System.out.printf("나이는 %d살이고 %s입니다.\n", Age ,Gender);
		System.out.printf("저는 '%s'에 살고 있습니다.",Address);
		
		


	}

}
