package com.afd.member.community;

public class ScrapDTO {
	private String comscrapseq;
	private String communityseq;
	private String memberseq;
	
	

	public String getCommunityseq() {
		return communityseq;
	}
	public String getComscrapseq() {
		return comscrapseq;
	}
	public void setComscrapseq(String comscrapseq) {
		this.comscrapseq = comscrapseq;
	}
	public void setCommunityseq(String communityseq) {
		this.communityseq = communityseq;
	}
	public String getMemberseq() {
		return memberseq;
	}
	public void setMemberseq(String memberseq) {
		this.memberseq = memberseq;
	}
	
}
